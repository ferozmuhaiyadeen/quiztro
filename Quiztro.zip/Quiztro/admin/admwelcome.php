<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>quiz</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72.png">
<link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57.png">
<link rel="shortcut icon" href="images/ico/favicon.png">

<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/countdown.js"></script>
<script src="js/scripts.js"></script>

</head>
<body id="pagetop">

<div id="topcont" class="container clearfix">
	<div class="overlay clearfix">
		<div class="bodycontainer clearfix">
			<div class="block">
				<div class="centered">
					<h1><a title="" href="#">Welcome Admin</a></h1>
                    














<?php



error_reporting(0);

session_start();
        if(!isset($_SESSION['admname'])){
            $_GLOBALS['message']="Session Timeout.Click here to <a href=\"index.php\">Re-LogIn</a>";
        }
        else if(isset($_REQUEST['logout'])){
           unset($_SESSION['admname']);
            $_GLOBALS['message']="You are Loggged Out Successfully.";
            header('Location: index.php');
        }
?>

<html>
    <head>
        <title>OES-DashBoard</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <link rel="stylesheet" type="text/css" href="../oes.css"/>
    </head>
    <body>
        <?php
      
        if(isset($_GLOBALS['message'])) {
            echo "<div class=\"message\">".$_GLOBALS['message']."</div>";
        }
        ?>
        <div id="container">
           
            <div class="menubar">

                <form name="admwelcome" action="admwelcome.php" method="post">
                    <ul id="menu">
                        <?php if(isset($_SESSION['admname'])){ ?>
                        <li><input type="submit" value="LogOut" name="logout" class="subbtn" title="Log Out"/></li>
                        <?php } ?>
                    </ul>
                </form>
            </div>
            <div class="admpage">
                <?php if(isset($_SESSION['admname'])){ ?>

        
               
                <div class="container">
                    
                       
                
				
				
				
				<header>
    <div class="nav">
      <ul>
        <li class="Manage Users"><a href="usermng.php">Manage Users</a></li>
        <li class="Manage Subjects"><a href="submng.php">Manage Subjects</a></li>
        <li class="Manage Test Results"><a href="rsltmng.php">Manage Test Result</a></li>
        <li class="Prepare Questions"><a href="testmng.php?forpq=true">Prepare Questions</a></li>
        <li class="Manage Tests"><a href="testmng.php">Manage Tests</a></li>
      </ul>
    </div>
  </header>
<br><br><br><br><br><br><br><br><br><br><br><br>
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				</div>
                <?php }?>

            </div>

          <div id="footer">
          <p style="font-size:70%;color:#ffffff;"></b><br/> </p><p></p>
      </div>
      </div>
  </body>
</html>

                </div>
			</div>
		</div>
	</div>
</div>



</body>
</html>