
<?php


$dbserver="localhost";


$dbusername="root";



$dbpassword="root";


$dbname="oes";

?>

