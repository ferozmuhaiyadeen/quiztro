<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>quiztro</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72.png">
<link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57.png">
<link rel="shortcut icon" href="images/ico/favicon.png">

<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/countdown.js"></script>
<script src="js/scripts.js"></script>

</head>
<body id="pagetop">

<div id="topcont" class="container clearfix">
	<div class="overlay clearfix">
		<div class="bodycontainer clearfix">
			<div class="block">
				<div class="centered">
					
                    <div id="clock"></div>



					<?php



error_reporting(0);
session_start();
        if(!isset($_SESSION['stdname'])){
            $_GLOBALS['message']="Session Timeout.Click here to <a href=\"index.php\">Re-LogIn</a>";
        }
        else if(isset($_REQUEST['logout'])){
                unset($_SESSION['stdname']);
            $_GLOBALS['message']="You are Loggged Out Successfully.";
            header('Location: index.php');
        }
?>
<h1><a title="" href="#">Welcome User</a></h1>

<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <link rel="stylesheet" type="text/css" href="oes.css"/>
    </head>
    <body>
        <?php

        if($_GLOBALS['message']) {
            echo "<div class=\"message\">".$_GLOBALS['message']."</div>";
        }
        ?>
        <div id="container">

            <div class="menubar">

                <form name="stdwelcome" action="stdwelcome.php" method="post">
                    <ul id="menu">
                        <?php if(isset($_SESSION['stdname'])){ ?>
                        <li><input type="submit" value="LogOut" name="logout" class="subbtn" title="Log Out"/></li>
                        <br/>
						<br/>
						
						<?php } ?>
                    </ul>
                </form>
            </div>
            <div class="stdpage">
                <?php if(isset($_SESSION['stdname'])){ ?>






<header>
    <div class="nav">
      <ul>
        <li class="Manage Users"><a href="editprofile.php">Edit Profile</a></li>
         &nbsp &nbsp &nbsp
        <li class="Manage Test Results"><a href="stdtest.php">Take Test</a></li>
		 &nbsp &nbsp &nbsp
        <li class="Manage Test Results"><a href="resumetest.php">Resume Test</a></li>
		 &nbsp &nbsp &nbsp
        <li class="Manage Tests"><a href="viewresult.php">View Result</a></li>
		 &nbsp &nbsp &nbsp
      </ul>
   





 






























   </div>
  </header>

                </div>
                <?php }?>

            </div>

           <div id="footer">
          <p style="font-size:70%;color:#ffffff;"></b><br/> </p><p></p>
      </div>
      </div>
  </body>
</html>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>




                  
                </div>
			</div>
		</div>
	</div>
</div>

<div id="bottomcont" class="container clearfix">
    <div class="bodycontainer clearfix">
        <div class="block">
            <div class="centered">
                <link rel="stylesheet" href="css/style1.css">
				
			<h1>Do's and Dont's</h1>
<div class="steps">
  <ul style="list-style:none">
    <li>
     
      <p>Malpractises are not welcomed</p>
	  </li>
    <li>
     <p>The test can be resumed anytime within the allotted session</p>
      </li>
    <li>
      <p>Dont surf the net for answers,the clock is ticking on...</p>
       </li>
    <li>
     <p>No negative markings..so go for everything</p>
       </li>
    
     <li>
	 <p>Good Luck!!</p>
	 </li>
  </ul>
</div>
    <script src="js/jquery1.js"></script>
<script src="js/waypoints1.min.js"></script>

        <script src="js/index1.js"></script>	
                <hr />
                
                
            </div>
        </div>
    </div>
</div>

</body>
</html>
