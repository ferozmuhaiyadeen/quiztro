<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>quiz</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72.png">
<link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57.png">
<link rel="shortcut icon" href="images/ico/favicon.png">
<link rel="stylesheet" href="css/style.css">

<script src="js/jquery.js"></script>
<script src="js/countdown.js"></script>
<script src="js/scripts.js"></script>

</head>
<body id="pagetop">

<div id="topcont" class="container clearfix">
	<div class="overlay clearfix">
		<div class="bodycontainer clearfix">
			<div class="block">
				<div class="centered">
					<h1><a title="" href="#">Quiztro</a></h1>
                    <div id="clock"></div>









<?php



      error_reporting(0);
      session_start();
      include_once 'oesdb.php';


      if(isset($_REQUEST['register']))
      {
            header('Location: register.php');
      }
      else if($_REQUEST['stdsubmit'])
      {

 
          $result=executeQuery("select *,DECODE(stdpassword,'oespass') as std from student where stdname='".htmlspecialchars($_REQUEST['name'],ENT_QUOTES)."' and stdpassword=ENCODE('".htmlspecialchars($_REQUEST['password'],ENT_QUOTES)."','oespass')");
          if(mysql_num_rows($result)>0)
          {

              $r=mysql_fetch_array($result);
              if(strcmp(htmlspecialchars_decode($r['std'],ENT_QUOTES),(htmlspecialchars($_REQUEST['password'],ENT_QUOTES)))==0)
              {
                  $_SESSION['stdname']=htmlspecialchars_decode($r['stdname'],ENT_QUOTES);
                  $_SESSION['stdid']=$r['stdid'];
                  unset($_GLOBALS['message']);
                  header('Location: stdwelcome.php');
              }else
          {
              $_GLOBALS['message']="Check Your user name and Password.";
          }

          }
          else
          {
              $_GLOBALS['message']="Check Your user name and Password.";
          }
          closedb();
      }
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
  <head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <link rel="stylesheet" type="text/css" href="oes.css"/>
  </head>
  <body>
      <?php

        if($_GLOBALS['message'])
        {
         echo "<div class=\"message\">".$_GLOBALS['message']."</div>";
        }
      ?>

      <div id="container">


     <form id="stdloginform" action="index.php" method="post">
      <div class="menubar">

       <ul id="menu">
                    <?php if(isset($_SESSION['stdname'])){
                          header('Location: stdwelcome.php');}else{
                          
                        ?>

                    
           <li><div class="aclass"><a href="register.php" title="Click here  to Register">Register</a></div></li>
                        <?php } ?>
                    </ul>

      </div>
      <div class="page">

              <table cellpadding="30" cellspacing="10">
              <tr>
                  <td>User Name</td>
                  <td><input type="text" tabindex="1" name="name" value="" size="16" /></td>

              </tr>
			   <tr><td><br></td></tr>   
              <tr>
                  <td>Password</td>
                  <td><input type="password" tabindex="2" name="password" value="" size="16" /></td>
              </tr>
 <tr><td><br></td></tr>   
              <tr>
                  <td colspan="2">
                      <input type="submit" tabindex="3" value="Log In" name="stdsubmit" class="subbtn" />
                  </td><td></td>
              </tr>
            </table>


      </div>
       </form>

    <div id="footer">
          <p style="font-size:70%;color:#ffffff;"><b></b><br/> </p><p></p>
      </div>
      </div>
  </body>
</html>










                   <div id="socialmedia" class="clearfix">
                        <ul>
                            <li><a title="" href="#" rel="external"><span class="fa fa-facebook"></span></a></li>
                            <li><a title="" href="#" rel="external"><span class="fa fa-twitter"></span></a></li>
                            <li><a title="" href="#" rel="external"><span class="fa fa-google-plus"></span></a></li>
                            <li><a title="" href="#" rel="external"><span class="fa fa-linkedin"></span></a></li>
                            <li><a title="" href="#" rel="external"><span class="fa fa-pinterest"></span></a></li>
                        </ul>
                    </div>
                   <br><br><br><br>
                </div>
			</div>
		</div>
	</div>
</div>

<div id="bottomcont" class="container clearfix">
    <div class="bodycontainer clearfix">
        <div class="block">
            <div class="centered">
                <h2>Welcome</h2>
                <p>Already been here before?Just login!!<br>New around here?Register yourself to enjoy!!</p>
                <hr />
               
                
            </div>
        </div>
    </div>
</div>

</body>
</html>
